#include <stdio.h>
#include<unistd.h>

void pwd();

int cd(char path);

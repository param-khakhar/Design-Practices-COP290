#include <stdio.h> 
#include <string.h>

char** process(char *input);

void handle_unpiped(char** tokens,int input,int output);

